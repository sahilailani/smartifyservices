
const controller = require('./file.controller');
const routes = require('./file.routes');
const fileupload = require('./fileupload')


module.exports = { controller, routes, fileupload };